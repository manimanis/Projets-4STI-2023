-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : ven. 10 mai 2024 à 08:19
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `animebook`
--

-- --------------------------------------------------------

--
-- Structure de la table `anime`
--

CREATE TABLE `anime` (
  `aid` int(11) NOT NULL,
  `aname` varchar(32) NOT NULL,
  `adesc` text NOT NULL,
  `rating` decimal(5,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `anime`
--

INSERT INTO `anime` (`aid`, `aname`, `adesc`, `rating`) VALUES
(1, 'hunter x hunter', 'The show centers around Gon Freecss, a 12-year-old boy who goes on an adventure to become a Hunter in hopes of finding his father. The Hunters Association holds an annual exam to determine if applicants are worthy of a Hunter\'s license which is for elite humans with extraordinary abilities', 0),
(2, 'naruto', 'His carefree, optimistic, and boisterous personality enables him to befriend other Konoha ninjas, as well as ninja from other villages.', 0),
(3, 'attack on titan', 'Attack On Titan is about how a boy\'s life changes when he loses his family to titans. The main protagonist is a 15-year-old named Eren Yeager who lives with his sister and parents until one day, his village is destroyed by giants called titans', 0),
(4, 'sword art online', 'SWORD ART ONLINE is the story of a multiplayer virtual-reality game that takes a deadly turn when players discover they can\'t escape of their own will but must play to victory or to death', 0),
(5, 'one piece', 'The series focuses on Monkey D. Luffy—a young man made of rubber after unintentionally eating a Devil Fruit—who sets off on a journey from the East Blue Sea to find the deceased King of the Pirates Gol D. Roger\'s ultimate treasure known as the \"One Piece\", and take over his prior title', 0);

-- --------------------------------------------------------

--
-- Structure de la table `revs`
--

CREATE TABLE `revs` (
  `rid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `aid` int(11) NOT NULL,
  `title` varchar(32) NOT NULL,
  `description` text NOT NULL,
  `likes` int(11) NOT NULL,
  `dislike` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `uname` varchar(32) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `email` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`userid`, `uname`, `passwd`, `email`) VALUES
(3, 'adam', '8de351db99e32c9c8ec55828acdde2f4', 'shadowzzr00@gmail.com');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `anime`
--
ALTER TABLE `anime`
  ADD PRIMARY KEY (`aid`);

--
-- Index pour la table `revs`
--
ALTER TABLE `revs`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `fk1` (`aid`),
  ADD KEY `fk2` (`uid`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `revs`
--
ALTER TABLE `revs`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `revs`
--
ALTER TABLE `revs`
  ADD CONSTRAINT `fk1` FOREIGN KEY (`aid`) REFERENCES `anime` (`aid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2` FOREIGN KEY (`uid`) REFERENCES `users` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
